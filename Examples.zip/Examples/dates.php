<?php 


// Create a new DateTime Object
$date = new DateTime('2017-04-20');

// Modify the date
$date->modify('+1 week');

?>

<div>
    <?php for($i = 0; $i < 7; $i++) : ?>
        <p><?php echo $date->format('l, M d Y') ?></p>
        <?php $date->modify('+1 day'); ?>
    <?php endfor; ?>
</div>