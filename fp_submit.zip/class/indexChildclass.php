<?php

include('config.php');

$child = new Childclass($childlname, $childfname); 
	
	$childlname = $childlname,
	$childfname = $childfname
	
	echo "New child added: ".$child->getchildfname." ".$child->getchildlname.".";	
}
?>