<?php

	class Childclass {
		protected $childlname;
		protected $childfname;
		protected $childID;
		protected $childDB
		
		function __construct($childID, $childDB) {
			$this->childId = $childId;
			$this=>childDb = $childDb;
			
			
			$sql = file_get_contents('sql/insertChild.sql');
			$params = array( 
            'childID' => $new_childId
                        
        );
        
        $statement = $database->prepare($sql);
        $statement->execute($params);
		$children = $statement->fetchAll(PDO::FETCH_ASSOC);
		
		$child = $children[0];
		}
		
		function get($childId) {
			return $this->childId;
		}
		
		function set($childId, $childlname, $childfname) {
			return $this->childId = $childlname;
					this->childId = $childfname;			
			
		}
		
		
		
	}
?>