select fpchild.cfirstName,
		fpchild.clastName,
        fpteacher.t_firstname,
        fpteacher.t_lastName
        
from 	fpchild,
		fpteacher
        
where fpchild.teacherID = fpteacher.teacherID
and fpteacher.teacherID = '3'
        
