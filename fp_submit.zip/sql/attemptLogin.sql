select *
from fpusers
where username = :username
	and password = :password