insert into fpchild (clastName, cfirstName, street, city, cstate, zipcode )
 values (:lname, :fname, :street, :city, :state, :zip )