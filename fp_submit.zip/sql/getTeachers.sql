SELECT * 
FROM fpteacher