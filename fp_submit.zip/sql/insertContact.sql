insert into fpcontacts (contactlname, contactfname, contactphone, contactemail)
values (:lname, :fname, :phone, :email)