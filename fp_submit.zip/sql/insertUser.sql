insert into fpusers (username, password, roleID)
values (username, password, roleID)