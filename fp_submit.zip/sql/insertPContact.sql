insert into fppcontacts (pcolastName, pcofirstName, pcoPhone, pcoEmail, pcostreet, pcocity, pcostate, pcozipcode )
 values (:lname, :fname, :phone, :email, :street, :city, :state, :zip )