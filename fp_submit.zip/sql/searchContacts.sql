select *
from fpcontacts
where contactlname like :term