insert into fpteacher (t_lastName, t_firstname, classroom, salary)
values (:lname, :fname, :classroom, :salary)